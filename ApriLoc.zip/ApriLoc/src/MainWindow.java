import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

public class MainWindow extends JFrame{
	private static final long serialVersionUID = 287342862345L;
	
	
	public MainWindow(){
		this.setTitle("ApriLoc");
		this.setUndecorated(true);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int width = (int)screenSize.getWidth();
		
		add(new MainPanel());
		pack();
		int packedHeight = this.getHeight();
		this.setSize(width, packedHeight);
		
	}
}
