import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class PasswordUserWindow extends JFrame{

	private static final long serialVersionUID = 2698147132277202614L;
	JFrame thisFrame = this;
	JPasswordField newPasswordTF, confirmPasswordTF;
	JLabel newPasswordLabel, confirmPasswordLabel;
	JButton doneButton;
	JPanel fieldsPanel;
	
	public PasswordUserWindow(){
		this.setTitle("Change Password");
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setLayout(new BorderLayout());
		this.setLocationRelativeTo(null);
		newPasswordLabel = new JLabel("New Password: ");
		newPasswordTF = new JPasswordField();
		confirmPasswordLabel = new JLabel("Confirm Password: ");
		confirmPasswordTF = new JPasswordField();
		doneButton = new JButton("Done");
		fieldsPanel = new JPanel(new GridLayout(2, 2));
		doneButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!passwordsMatch()){
					passwordsDontMatch();
					return;
				}
				String password = getPassword(newPasswordTF);
				if(!CurrentUser.getUser().changePassword(password))
					showRequirements();
				else
					thisFrame.dispose();
				ServerConnection.updateUser(CurrentUser.getUser());
			}
		});
		newPasswordTF.setPreferredSize(new Dimension(155, 19));
		
		fieldsPanel.add(newPasswordLabel);
		fieldsPanel.add(newPasswordTF);
		fieldsPanel.add(confirmPasswordLabel);
		fieldsPanel.add(confirmPasswordTF);
		this.add(fieldsPanel, BorderLayout.NORTH);
		this.add(doneButton, BorderLayout.SOUTH);
		pack();
	}
	
	private String getPassword(JPasswordField passwordField){
		char[] charPassword = passwordField.getPassword();
		String strPassword = "";
		for(char character : charPassword)
			strPassword += character;
		return strPassword;
	}
	
	private boolean passwordsMatch(){
		String newPassword = getPassword(newPasswordTF);
		String confirmPassword = getPassword(confirmPasswordTF);
		return newPassword.equals(confirmPassword);
	}
	
	private void passwordsDontMatch(){
		JOptionPane.showMessageDialog(this,
				"Passwords Don't Match", "Error", JOptionPane.ERROR_MESSAGE);
	}
	
	private void showRequirements(){
		JOptionPane.showMessageDialog(this,
				"Invalid password.\nThe password must follow these requirments:\nAt least 8 characters\nOne uppercase character\nOne lowercase character\nOne digit\nOne non alphanumeric character\nCan not be your previous password", "Error", JOptionPane.ERROR_MESSAGE);
	}

}
