import java.io.FileNotFoundException;

public class Driver {

	public static void main(String[] args) {
		ServerConnection.connectToServer("127.0.0.1", 5555);
		if(ServerConnection.getAllUsers().size() == 0){
			new WelcomeWindow();
		}else{
			new MainWindow();
		}
		
	}

}
