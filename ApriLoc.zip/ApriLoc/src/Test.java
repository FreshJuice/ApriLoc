import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		ServerConnection.connectToServer("127.0.0.1", 5555);
		User user = ServerConnection.getUser(5);
		user.setName("Hello friend");
		ArrayList<User> allUsers = ServerConnection.getAllUsers();
		for (User user2 : allUsers){
			System.out.println(user2 + "\n");
			user2.setName(user2.getName() + "yoyo");
		}
		ServerConnection.updateUser(user);
		ServerConnection.updateUser(allUsers.get(0));
		ServerConnection.updateUser(allUsers.get(1));
		allUsers = ServerConnection.getAllUsers();
		for (User user2 : allUsers){
			System.out.println(user2 + "\n");
		}
	}

}
