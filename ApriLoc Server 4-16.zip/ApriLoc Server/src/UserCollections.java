import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class UserCollections implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7274227535944212631L;
	private static ArrayList<User> userList = new ArrayList<User>();
	private static ArrayList<LogEntry> logList = new ArrayList<LogEntry>();
	private static ArrayList<RegistryForm> registryList = new ArrayList<RegistryForm>();

	public static void readListsFromFile(String folderPath) throws Exception {
		userList = Database.readUsersFromFile(folderPath);
		logList = Database.readLogsFromFile(folderPath);
		registryList = Database.readRegistryFormsFromFile(folderPath);
	}

	public static void sortUserListByName() {
		Collections.sort(userList, new Comparator<User>() {
			@Override
			public int compare(User user1, User user2) {
				return user1.getName().compareTo(user2.getName());
			}
		});
	}

	public static void sortUserListByID() {
		Collections.sort(userList, new Comparator<User>() {
			@Override
			public int compare(User user1, User user2) {
				if (user1.getUserID() < user2.getUserID())
					return -1;
				else if (user1.getUserID() == user2.getUserID())
					return 0;
				else
					return 1;
			}
		});
	}
	
	public static void addLogEntry(LogEntry logEntry){
		logList.add(logEntry);
		try {
			Database.saveLogsToFile(Database.DATABASE_FOLDER);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static void addRegistryForm(RegistryForm registryForm){
		registryList.add(registryForm);
		try {
			Database.saveRegistryFormsToFile(Database.DATABASE_FOLDER);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static void removeRegistryForm(int userID){
		for(int i = 0; i < registryList.size(); i++){
			if(registryList.get(i).getUserId() == userID){
				registryList.remove(i);
			}
		}
		try {
			Database.saveRegistryFormsToFile(Database.DATABASE_FOLDER);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static void forceAddUser(User userAccount){
		userList.add(userAccount);
	}
	
	public static boolean addUser(User userAccount) {
		for (int i = 0; i < userList.size(); i++) {
			if (userList.get(i).getUserID() == userAccount.getUserID())
				return false;
		}
		userList.add(userAccount);
		try {
			Database.saveUsersToFile(Database.DATABASE_FOLDER);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return true;
	}

	public static User removeUser(int userID) {
		User removedUser = null;
		for (int i = 0; i < userList.size(); i++) {
			if (userList.get(i).getUserID() == userID) {
				removedUser = userList.get(i);
				userList.remove(i);
				break;
			}
		}
		try {
			Database.saveUsersToFile(Database.DATABASE_FOLDER);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return removedUser;
	}

	public static User getUser(int userID) {
		for (int i = 0; i < userList.size(); i++) {
			if (userList.get(i).getUserID() == userID) {
				return userList.get(i);
			}
		}
		return null;
	}

	public static ArrayList<User> getUserList() {
		return userList;
	}

	public static ArrayList<LogEntry> getLogEntryList() {
		return logList;
	}

	public static ArrayList<RegistryForm> getRegistryFormList() {
		return registryList;
	}

	public static LogEntry getUserLogEntry(int userID) {
		return null;
	}

	public static void setUserList(ArrayList<User> users){
		userList = users;
	}
	
	public static void setRegistryFormList(ArrayList<RegistryForm> registryForms){
		registryList = registryForms;
	}
	
	public static void setLogEntryList(ArrayList<LogEntry> logs){
		logList = logs;
	}
	
	public static void printUserList() {
		for(int i = 0; i < userList.size(); i++){
			System.out.println(userList.get(i));
		}
	}

	public static void printLogList() {
		for(int i = 0; i < userList.size(); i++){
			System.out.println(logList.get(i));
		}
	}

}
