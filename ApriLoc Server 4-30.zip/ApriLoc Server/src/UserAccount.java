import java.io.Serializable;
import java.util.ArrayList;

public class UserAccount extends User implements Serializable{

	private static final long serialVersionUID = 7233552351008075950L;

	public UserAccount(String name, int userID, String phoneNumber) {
		super(name, userID, phoneNumber, false);
	}

	public UserAccount(String name, int userID, String phoneNumber, byte[] passwordHash,
			ArrayList<String> priviledgeList, boolean locked, long passwordTimeStamp) {
		super(name, userID, phoneNumber, passwordHash, priviledgeList, locked, false, passwordTimeStamp);
	}

}
