import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

import javax.xml.crypto.Data;

public class UserCollections {
	private static ArrayList<User> userList = new ArrayList<User>();
	private static ArrayList<LogEntry> logList = new ArrayList<LogEntry>();
	private static ArrayList<RegistryForm> registryList = new ArrayList<RegistryForm>();

	public static void readListsFromFile(String folderPath) throws Exception {
		userList = Database.readUsersFromFile(folderPath);
		logList = Database.readLogsFromFile(folderPath);
		registryList = Database.readRegistryFormsFromFile(folderPath);
	}

	public static void sortUserListByName() {
		Collections.sort(userList, new Comparator<User>() {
			@Override
			public int compare(User user1, User user2) {
				return user1.getName().compareTo(user2.getName());
			}
		});
	}

	public static void sortUserListByID() {
		Collections.sort(userList, new Comparator<User>() {
			@Override
			public int compare(User user1, User user2) {
				if (user1.getUserID() < user2.getUserID())
					return -1;
				else if (user1.getUserID() == user2.getUserID())
					return 0;
				else
					return 1;
			}
		});
	}
	
	public static void addLogEntry(LogEntry logEntry){
		logList.add(logEntry);
	}
	
	public static void addRegistryForm(RegistryForm registryForm){
		registryList.add(registryForm);
	}
	
	public static void forceAddUser(User userAccount){
		userList.add(userAccount);
	}
	
	public static boolean addUser(User userAccount) {
		for (int i = 0; i < userList.size(); i++) {
			if (userList.get(i).getUserID() == userAccount.getUserID())
				return false;
		}
		userList.add(userAccount);
		return true;
	}

	public static User removeUser(int userID) {
		for (int i = 0; i < userList.size(); i++) {
			if (userList.get(i).getUserID() == userID) {
				User removedUser = userList.get(i);
				userList.remove(i);
				return removedUser;
			}
		}
		return null;
	}

	public static User getUser(int userID) {
		for (int i = 0; i < userList.size(); i++) {
			if (userList.get(i).getUserID() == userID) {
				return userList.get(i);
			}
		}
		return null;
	}

	public static ArrayList<User> getUserList() {
		return userList;
	}

	public static ArrayList<LogEntry> getLogEntryList() {
		return logList;
	}

	public static ArrayList<RegistryForm> getRegistryFormList() {
		return registryList;
	}

	public static LogEntry getUserLogEntry(int userID) {
		return null;
	}

	public static void printUserList() {
		for(int i = 0; i < userList.size(); i++){
			System.out.println(userList.get(i));
		}
	}

	public static void printLogList() {
		for(int i = 0; i < userList.size(); i++){
			System.out.println(logList.get(i));
		}
	}

}
