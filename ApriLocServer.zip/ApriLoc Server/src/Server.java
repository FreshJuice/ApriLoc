import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Server extends ServerSocket {

	private static ArrayList<Socket> clients;

	public Server(int port) throws IOException {
		super(port);
		clients = new ArrayList<Socket>();
	}

	public void listenForClients() {
		new Thread() {
			@Override
			public void run() {
				while (true) {
					Socket newClient = null;
					try {
						newClient = accept();
					} catch (IOException e) {
						e.printStackTrace();
					}
					clients.add(newClient);
					OnNewConnection(newClient);
					new MessageInterface(newClient);
					super.run();
				}
			}
		}.start();
	}

	public static void disconnect(Socket client) {
		for (int i = 0; i < clients.size(); i++) {
			if (clients.get(i).equals(client)) {
				clients.remove(i);
			}
		}
		System.out.println("SERVER - " + client.getInetAddress().getHostAddress() + " Disconnected");
	}

	public void OnNewConnection(Socket newClient) {
		System.out.println("SERVER - " + newClient.getInetAddress().getHostAddress() + " Connected");

	}
}
