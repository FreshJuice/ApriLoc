import java.io.IOException;

public class Test {

	public static void main(String[] args) {
		Server server = null;
		
		try {
			server = new Server(5555);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("SERVER - Listening");
		server.listenForClients();
	}

}
