import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class RegisterDeviceWindow {
	JFrame frame;
	JLabel infoLabel, userIDLabel, macLabel;
	JTextField userIDTF, macTF;
	JButton registerButton;

	public RegisterDeviceWindow() {
		initFrame();
	}

	private void initFrame() {
		JPanel infoGrid = new JPanel(new GridLayout(2, 2));

		frame = new JFrame("Register Device");
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setLayout(new BorderLayout());
		frame.setLocationRelativeTo(null);

		infoLabel = new JLabel(" Register Device ");
		infoLabel.setFont(new Font("Ariel", Font.PLAIN, 28));

		userIDLabel = new JLabel("User ID:");
		userIDTF = new JTextField();

		macLabel = new JLabel("Mac Address:");
		macTF = new JTextField();

		registerButton = new JButton("Register");
		registerButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int userID;
				try {
					userID = Integer.parseInt(userIDTF.getText());
				} catch (NumberFormatException exception) {
					invalidUserID();
					return;
				}

				User temp = ServerConnection.getUser(userID);

				if (temp == null) {
					userNotExist();
					return;
				}

				if (macTF.getText().replaceAll("[^a-fA-F0-9]", "").length() != 12) {
					invalidMac();
					return;
				}

				byte[] mac = toByteArray(macTF.getText().replaceAll("[^a-fA-F0-9]", ""));
				
				if(areEqualArrays(temp.getDeviceList()[0], mac) || areEqualArrays(temp.getDeviceList()[1], mac)){
					alreadyRegistered();
					return;
				}
				
				if(!temp.addDevice(mac)){
					tooManyDevices();
					return;
				}else{
					ServerConnection.updateUser(temp);
					frame.dispose();
					success();
				}
			}
		});

		infoGrid.add(userIDLabel);
		infoGrid.add(userIDTF);
		infoGrid.add(macLabel);
		infoGrid.add(macTF);

		frame.getContentPane().add(infoLabel, BorderLayout.NORTH);
		frame.getContentPane().add(infoGrid, BorderLayout.CENTER);
		frame.getContentPane().add(registerButton, BorderLayout.SOUTH);
		frame.pack();
	}

	private boolean areEqualArrays(byte[] array1, byte[] array2) {
		if(array1.length != array2.length)
			return false;
		
		for (int i = 0; i < array1.length; i++) {
			if(array1[i] != array2[i])
				return false;
		}
		return true;
	}
	
	private byte[] toByteArray(String macAddr) {
		byte[] data = new byte[6];
	    for (int i = 0; i < macAddr.length(); i += 2) {
	        data[i / 2] = (byte) (Integer.parseInt(macAddr.substring(i, i+2), 16));
	    }
	    return data;
	}

	private void userNotExist() {
		JOptionPane.showMessageDialog(null, "User ID does not exist", "Error", JOptionPane.ERROR_MESSAGE);
	}

	private void success() {
		JOptionPane.showMessageDialog(null, "Device successfully added to user", "Success",
				JOptionPane.INFORMATION_MESSAGE);
	}

	private void alreadyRegistered() {
		JOptionPane.showMessageDialog(null, "Device already registered", "Error", JOptionPane.ERROR_MESSAGE);
	}

	private void tooManyDevices() {
		JOptionPane.showMessageDialog(null, "User already has 2 devices registered", "Error",
				JOptionPane.ERROR_MESSAGE);
	}

	private void invalidUserID() {
		JOptionPane.showMessageDialog(null, "User ID must be a number from 1 - 2147483647", "Error",
				JOptionPane.ERROR_MESSAGE);
	}
	
	private void invalidMac() {
		JOptionPane.showMessageDialog(null, "Invalid MAC Address", "Error",
				JOptionPane.ERROR_MESSAGE);
	}
}
