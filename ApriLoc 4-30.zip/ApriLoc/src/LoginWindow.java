import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class LoginWindow extends JFrame implements ActionListener, Serializable{

	private static final long serialVersionUID = -4114818234598760870L;

	LoginSession loginSession;
	JLabel userIDLabel, passwordLabel, textCodeLabel;
	JTextField userIDTF, textCodeTF;
	JPasswordField passwordTF;
	JButton loginButton, sendCodeButton;
	FieldPanel fieldPanel;
	MainPanel mainPanel;
	
	public LoginWindow(MainPanel mainPanel) {
		this.mainPanel = mainPanel;
		this.setTitle("Login");
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setLayout(new BorderLayout());
		this.setLocationRelativeTo(null);

		initializeComponents();

		loginButton.addActionListener(this);
		fieldPanel = new FieldPanel(false);
		this.add(fieldPanel, BorderLayout.NORTH);
		this.add(sendCodeButton, BorderLayout.SOUTH);
		pack();
	}

	public void initializeComponents() {
		userIDLabel = new JLabel("User ID: ");
		passwordLabel = new JLabel("Password: ");
		textCodeLabel = new JLabel("Text Code: ");

		userIDTF = new JTextField();
		userIDTF.setPreferredSize(new Dimension(125, 19));
		textCodeTF = new JTextField();
		textCodeTF.setPreferredSize(new Dimension(125, 19));
		passwordTF = new JPasswordField();
		passwordTF.setPreferredSize(new Dimension(125, 19));

		loginButton = new JButton("Login");
		sendCodeButton = new JButton("Send Code");

		sendCodeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int userID = -1;
				try {
					userID = Integer.parseInt(userIDTF.getText());
				} catch (Exception ex) {
					invalidCredentials();
					return;
				}
				
				User temp = ServerConnection.getUser(userID);
				
				if(temp == null){
					invalidCredentials();
					return;
				}
				CurrentUser.setUser(temp);
				
				String password = "";
				for (char character : passwordTF.getPassword()) {
					password += character;
				}

				loginSession = new LoginSession(userID, password, "");

				if (loginSession.isNewUser()) {
					setupNewUser(CurrentUser.getUser());
					return;
				}
				
				if(CurrentUser.getUser().isLocked()){
					ServerConnection.sendLoginAttempt(false);
					accountLocked();
					return;
				}
				
				if(CurrentUser.getUser().isSuspended()){
					ServerConnection.sendLoginAttempt(false);
					accountSuspended(CurrentUser.getUser().getSuspendUntilTimeStamp());
					return;
				}
				
				if (!loginSession.isCorrectPassword()) {
					User user = CurrentUser.getUser();
					if(!user.isAdmin()){
						user.setLoginAttempts(user.getLoginAttempts()+1);
						if(user.getLoginAttempts() == 3){
							user.suspendUser(5);
						}else if(user.getLoginAttempts() == 4){
							user.suspendUser(15);
						}else if(user.getLoginAttempts() == 5){
							user.setLocked(true);
						}
					}
					ServerConnection.updateUser(user);
					ServerConnection.sendLoginAttempt(false);
					invalidCredentials();
					return;
				}

				if (CurrentUser.getUser().isLoggedIn()) {
					ServerConnection.sendLoginAttempt(false);
					alreadyLoggedIn();
					return;
				}
				
				if(loginSession.checkExpiredPassword()){
					return;
				}
				
				loginSession.sendTextCode();
				getContentPane().removeAll();
				getContentPane().repaint();
				fieldPanel = new FieldPanel(true);
				getContentPane().add(fieldPanel, BorderLayout.NORTH);
				getContentPane().add(loginButton, BorderLayout.SOUTH);
				userIDTF.setEditable(false);
				passwordTF.setEditable(false);
				pack();
			}
		});
	}

	public void setupNewUser(User user) {
		JOptionPane.showMessageDialog(this, "You are a new user, please enter an initial password: ", "New User", JOptionPane.INFORMATION_MESSAGE);
		new PasswordUserWindow(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) { // Login button pressed
		User getUser = ServerConnection.getUser(CurrentUser.getUser().getUserID());
		CurrentUser.setUser(getUser);
		User user = CurrentUser.getUser();
		loginSession.setEnteredTextCode(textCodeTF.getText());// Initialize
																				// LoginSession
		if (!loginSession.isRegisteredDevice()) { // check registered device
			ServerConnection.sendLoginAttempt(false);
			invalidDevice();
			return;
		} else if (!loginSession.isValidLogin()) { // check everything else
			if(!user.isAdmin()){
				user.setLoginAttempts(user.getLoginAttempts()+1);
				if(user.getLoginAttempts() == 3){
					user.suspendUser(5);
				}else if(user.getLoginAttempts() == 4){
					user.suspendUser(15);
				}else if(user.getLoginAttempts() == 5){
					user.setLocked(true);
				}
			}
			ServerConnection.sendLoginAttempt(false);
			invalidTextCode();
			return;
		} else {
			loginSession.connectToServer(); // connect
			this.dispose();
			ServerConnection.sendLoginAttempt(true);
			mainPanel.loggedIn();
		}

	}

	private void accountLocked() {
		JOptionPane.showMessageDialog(this, "Account Locked Indefinetly, Please Contact a System Administrator", "Error", JOptionPane.ERROR_MESSAGE);
	}
	private void accountSuspended(long suspendUntil) {
		JOptionPane.showMessageDialog(this, "Account Suspened for " + ((suspendUntil - System.currentTimeMillis()) / 1000L / 60L) + " minutes", "Error", JOptionPane.ERROR_MESSAGE);
	}
	
	private void invalidCredentials() {
		JOptionPane.showMessageDialog(this, "Invalid UserID or Password", "Error", JOptionPane.ERROR_MESSAGE);
	}

	private void invalidTextCode() {
		JOptionPane.showMessageDialog(this, "Invalid Text Code", "Error", JOptionPane.ERROR_MESSAGE);
	}

	private void invalidDevice() {
		JOptionPane.showMessageDialog(this, "Device Not Registered", "Error", JOptionPane.ERROR_MESSAGE);
	}

	private void alreadyLoggedIn() {
		JOptionPane.showMessageDialog(this, "User Already Logged In", "Error", JOptionPane.ERROR_MESSAGE);
	}

	private class FieldPanel extends JPanel {
		private static final long serialVersionUID = 1646456957334474816L;

		public FieldPanel(boolean textCode) {
			if (textCode) {
				this.setLayout(new GridLayout(3, 2));
				add(userIDLabel);
				add(userIDTF);
				add(passwordLabel);
				add(passwordTF);
				add(textCodeLabel);
				add(textCodeTF);
			} else {
				this.setLayout(new GridLayout(2, 2));
				add(userIDLabel);
				add(userIDTF);
				add(passwordLabel);
				add(passwordTF);
			}
		}
	}
}
