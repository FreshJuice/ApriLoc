import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.CompoundBorder;
import javax.swing.table.DefaultTableModel;


	public class ViewRegistryWindow extends JFrame{
		private static final long serialVersionUID = 672879095819277665L;

		static JTable table;
		JScrollPane scroll;
		static ArrayList<RegistryForm> formArray;
		static Object allRegistryForms[][];
		static String[] cols = {"First Name","Privlage Requested","Reason","ID","Status"};
		JPanel userList;
		JPanel panel;
		static DefaultTableModel model;
		
		
		public ViewRegistryWindow() {
			// Creates the Frame
			this.setTitle("Registry Forms");
			this.setVisible(true);
			this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

			// Main Panel
			panel = new JPanel();
			panel.setLayout(new GridBagLayout());
			GridBagConstraints c = new GridBagConstraints();
			c.gridx = 0;
			c.gridy = 0;

			// Sub Panel for drop down
			JPanel typeUser = new JPanel();
			typeUser.setLayout(new GridBagLayout());
			
			
			
			
			c.gridx = 0;
			c.gridy = 0;
			panel.add(typeUser);
			
			// Sub Panel for reason
			userList = new JPanel();
			CompoundBorder tb = BorderFactory.createCompoundBorder();
			userList.setBorder(tb);

			
			
		
			allRegistryForms = new Object[ServerConnection.getRegistryForms().size()][5]; //num rows uknown col is fixed
			formArray = ServerConnection.getRegistryForms();
			for(int i = 0; i < formArray.size(); i ++){
				RegistryForm processForm = (RegistryForm) formArray.get(i);
				allRegistryForms [i][0] = ServerConnection.getUser(processForm.getUserId()).getName();
				allRegistryForms [i][1] = processForm.getRequestedPrivlage();
				allRegistryForms [i][2] = processForm.getBodyText();
				allRegistryForms [i][3] = processForm.getUserId();
				if(processForm.isPending()){
					allRegistryForms [i][4] = "PENDING";
				}
				else{
					if(processForm.isApproved()){
						allRegistryForms [i][4] = "APPROVED";
					}
					else{
						allRegistryForms [i][4] = "DENIED";
					}
				}
				
			}
			table = new JTable();
			 model = new DefaultTableModel(allRegistryForms,cols);
			 table.setModel(model);
			 
			 
			table.setDefaultEditor(Object.class, null);
			table.setBackground(Color.yellow);
			table.setForeground(Color.blue);
			userList.add(new JScrollPane(table));
			c.gridy++;
			panel.add(userList, c);
			
			
			table.addMouseListener(new MouseAdapter() {
			    public void mousePressed(MouseEvent me) {
			        JTable table =(JTable) me.getSource();
			        Point p = me.getPoint();
			        int row = table.rowAtPoint(p);
			        if (me.getClickCount() == 2) {
			            new DetailRegistryFormWindow(formArray.get(row));
			            
			        }
			    }
			});
			
			
			this.add(panel);
			this.pack();

		}

		
		public static void updateJTable(){
			allRegistryForms = new Object[ServerConnection.getRegistryForms().size()][5]; //num rows uknown col is fixed
			for(int i = 0; i < formArray.size(); i ++){
				RegistryForm processForm = (RegistryForm) formArray.get(i);
				allRegistryForms [i][0] = ServerConnection.getUser(processForm.getUserId()).getName();
				allRegistryForms [i][1] = processForm.getRequestedPrivlage();
				allRegistryForms [i][2] = processForm.getBodyText();
				allRegistryForms [i][3] = processForm.getUserId();
				if(processForm.isPending()){
					allRegistryForms [i][4] = "PENDING";
				}
				else{
					if(processForm.isApproved()){
						allRegistryForms [i][4] = "APPROVED";
						System.out.println(allRegistryForms [i][4]);
					}
					else{
						allRegistryForms [i][4] = "DENIED";
					}
				}
				
			}
			
			 model = new DefaultTableModel(allRegistryForms,cols);
			 
			 table.setModel(model);
			 model.fireTableDataChanged();
		}
					
				
						
					
				
				
		}
	
		
	