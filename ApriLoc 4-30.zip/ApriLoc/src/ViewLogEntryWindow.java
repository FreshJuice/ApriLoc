import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.CompoundBorder;
import javax.swing.table.DefaultTableModel;

public class ViewLogEntryWindow extends JFrame {
	private static final long serialVersionUID = 672879095819277665L;

	static JTable table;
	JScrollPane scroll;
	static ArrayList<LogEntry> logArray;
	static Object allLogEntires[][];
	static String[] cols = { "ID entered", "# attempt", "Time," };
	JPanel logEntry;
	JPanel panel;
	static DefaultTableModel model;

	public ViewLogEntryWindow() {
		// Creates the Frame
		this.setTitle("Registry Forms");
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setLocationRelativeTo(null);
		// Main Panel
		panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;

		// Sub Panel for drop down
		JPanel typeUser = new JPanel();
		typeUser.setLayout(new GridBagLayout());

		c.gridx = 0;
		c.gridy = 0;
		panel.add(typeUser);

		// Sub Panel for reason
		logEntry = new JPanel();
		CompoundBorder tb = BorderFactory.createCompoundBorder();
		logEntry.setBorder(tb);

		allLogEntires = new Object[ServerConnection.getLogList().size()][3]; // num
																				// rows
																				// uknown
																				// col
																				// is
																				// fixed
		logArray = ServerConnection.getLogList();
		for (int i = 0; i < logArray.size(); i++) {
			LogEntry processForm = (LogEntry) logArray.get(i);
			allLogEntires[i][0] = processForm.getLoginID();
			allLogEntires[i][1] = processForm.getLoginAttemptNum();

			Date date = new Date(processForm.getTimeStamp());
			String formatDate = date.toString();

			allLogEntires[i][2] = formatDate.substring(0, 19);

		}
		table = new JTable();
		model = new DefaultTableModel(allLogEntires, cols);
		table.setModel(model);

		table.setDefaultEditor(Object.class, null);
		table.setBackground(Color.yellow);
		table.setForeground(Color.blue);
		logEntry.add(new JScrollPane(table));
		c.gridy++;
		panel.add(logEntry, c);

		this.add(panel);
		this.pack();

	}

}
