import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class RemoveDeviceWindow {
	JFrame frame;
	JLabel infoLabel, userIDLabel;
	JTextField userIDTF;
	JButton searchButton, registerButton;
	JComboBox<String> deviceDropDown;

	public RemoveDeviceWindow() {
		initFrame();
	}

	private void initFrame() {
		JPanel infoGrid = new JPanel(new GridLayout(1, 2));

		frame = new JFrame("Remove Device");
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setLayout(new BorderLayout());
		frame.setLocationRelativeTo(null);

		infoLabel = new JLabel(" Remove Device ");
		infoLabel.setFont(new Font("Ariel", Font.PLAIN, 28));

		userIDLabel = new JLabel("User ID:");
		userIDTF = new JTextField();

		searchButton = new JButton("Search");
		searchButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int userID;
				try {
					userID = Integer.parseInt(userIDTF.getText());
				} catch (NumberFormatException ex) {
					invalidUserID();
					return;
				}

				User user = ServerConnection.getUser(userID);
				if (user == null) {
					invalidUserID();
					return;
				}

				new DeviceListRemoveWindow(user);
			}
		});
		infoGrid.add(userIDLabel);
		infoGrid.add(userIDTF);

		frame.getContentPane().add(infoLabel, BorderLayout.NORTH);
		frame.getContentPane().add(infoGrid, BorderLayout.CENTER);
		frame.getContentPane().add(searchButton, BorderLayout.SOUTH);
		frame.pack();
	}

	private void invalidUserID() {
		JOptionPane.showMessageDialog(null, "User ID must be a number from 1 - 2147483647", "Error",
				JOptionPane.ERROR_MESSAGE);
	}
}
