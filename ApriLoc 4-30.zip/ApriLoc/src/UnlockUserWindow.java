import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class UnlockUserWindow {
	JFrame frame;
	JLabel infoLabel, userIDLabel;
	JTextField userIDTF;
	JButton unlockButton;

	public UnlockUserWindow() {
		initFrame();
	}

	private void initFrame() {
		JPanel infoGrid = new JPanel(new GridLayout(1, 2));

		frame = new JFrame("Unlock User");
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setLayout(new BorderLayout());
		frame.setLocationRelativeTo(null);

		infoLabel = new JLabel(" Unlock User ");
		infoLabel.setFont(new Font("Ariel", Font.PLAIN, 28));

		userIDLabel = new JLabel("User ID:");
		userIDTF = new JTextField();

		unlockButton = new JButton("Unlock");
		unlockButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int userID;
				try {
					userID = Integer.parseInt(userIDTF.getText());
				} catch (NumberFormatException exception) {
					invalidUserID();
					return;
				}

				User temp = ServerConnection.getUser(userID);

				if (temp == null) {
					userNotExist();
					return;
				}
				
				if(!temp.isLocked()){
					alreadyUnlocked();
					return;
				}
				
				int choice = JOptionPane.showConfirmDialog(null,
						"Are you sure you would like to unlock " + temp.getName() + " with ID: " + temp.getUserID(),
						"Unlock User?", JOptionPane.YES_NO_OPTION);
				if (choice == JOptionPane.YES_OPTION) {
					temp.setLocked(false);
					ServerConnection.updateUser(temp);
					success();
					frame.dispose();
				}

			}
		});

		infoGrid.add(userIDLabel);
		infoGrid.add(userIDTF);

		frame.getContentPane().add(infoLabel, BorderLayout.NORTH);
		frame.getContentPane().add(infoGrid, BorderLayout.CENTER);
		frame.getContentPane().add(unlockButton, BorderLayout.SOUTH);
		frame.pack();
	}

	private void userNotExist() {
		JOptionPane.showMessageDialog(null, "User ID does not exist", "Error", JOptionPane.ERROR_MESSAGE);
	}

	private void success() {
		JOptionPane.showMessageDialog(null, "User successfully unlocked", "Success", JOptionPane.INFORMATION_MESSAGE);
	}

	private void alreadyUnlocked() {
		JOptionPane.showMessageDialog(null, "User is not locked", "Error", JOptionPane.ERROR_MESSAGE);
	}

	private void invalidUserID() {
		JOptionPane.showMessageDialog(null, "User ID must be a number from 1 - 2147483647", "Error",
				JOptionPane.ERROR_MESSAGE);
	}
}
