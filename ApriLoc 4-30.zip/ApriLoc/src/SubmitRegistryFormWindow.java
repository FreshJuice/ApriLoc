import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

import com.twilio.rest.api.v2010.account.usage.record.ThisMonth;

public class SubmitRegistryFormWindow extends JFrame {
	private static final long serialVersionUID = 672879095819277665L;
	JComboBox<String> dropDown;
	String[] privlages;
	JTextArea textArea;
	JFrame frame = this;

	public SubmitRegistryFormWindow() {
		// Creates the Frame
		this.setTitle("Submit Registry Form");
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setLocationRelativeTo(null);
		// Main Panel
		JPanel panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;

		// Sub Panel for drop down
		JPanel privlagePanel = new JPanel();
		privlagePanel.setLayout(new GridBagLayout());
		JLabel selectL = new JLabel("Select Privlage:  ");
		privlages = new String[] { "Privlage 1", "Privlage 2", "Privlage 3", "Privlage 4", "Privlage 5" }; // Temporary
																											// privlages
		dropDown = new JComboBox<String>(privlages);
		privlagePanel.add(selectL, c);
		c.gridx++;
		privlagePanel.add(dropDown);
		c.gridx = 0;
		c.gridy = 0;
		panel.add(privlagePanel);

		// Sub Panel for reason
		JPanel reason = new JPanel();
		TitledBorder tb = BorderFactory.createTitledBorder("Reason");
		reason.setBorder(tb);
		textArea = new JTextArea(5, 30);
		reason.add(textArea);
		c.gridy++;
		panel.add(reason, c);

		// Submit Button
		JButton submit = new JButton("Submit");
		submit.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent event) {
				ServerConnection.sendRegistryForm(CurrentUser.getUser().getUserID(), privlages[dropDown.getSelectedIndex()],
						textArea.getText());
				success();
				frame.dispose();
			}

			private void success() {
				JOptionPane.showMessageDialog(frame, "Registry Form Successfully Sent", "Success",
						JOptionPane.INFORMATION_MESSAGE);
				
			}
		});
		c.gridy++;
		c.anchor = GridBagConstraints.LINE_END;
		panel.add(submit, c);

		this.add(panel);
		this.pack();

	}
}
