import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class DeviceListRemoveWindow {

	JFrame frame;
	JLabel infoLabel;
	JComboBox<String> deviceComboBox;
	JButton removeButton;
	User user;

	public DeviceListRemoveWindow(User user) {
		this.user = user;
		initFrame();
	}

	private void initFrame() {
		frame = new JFrame();
		frame.setTitle("Remove a Device");
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.setLayout(new BorderLayout());
		frame.setVisible(true);

		infoLabel = new JLabel("Select a device to remove:");

		deviceComboBox = new JComboBox<String>();
		String[] devices = getDevices();
		deviceComboBox.addItem(devices[0]);
		deviceComboBox.addItem(devices[1]);

		removeButton = new JButton("Remove Device");
		removeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(((String)deviceComboBox.getSelectedItem()).isEmpty()){
					return;
				}
				int selectedIndex = deviceComboBox.getSelectedIndex();
				if (selectedIndex == 1) {
					user.removeDevice(user.getDeviceList()[1]);
					success();
				} else if (selectedIndex == 0) {
					user.removeDevice(user.getDeviceList()[0]);
					success();
				}
				
			}
		});
		frame.add(infoLabel, BorderLayout.NORTH);
		frame.add(deviceComboBox, BorderLayout.CENTER);
		frame.add(removeButton, BorderLayout.SOUTH);
		frame.pack();
	}

	private String[] getDevices() {
		StringBuilder strMac1 = new StringBuilder();
		StringBuilder strMac2 = new StringBuilder();
		byte[] mac1 = user.getDeviceList()[0];
		byte[] mac2 = user.getDeviceList()[1];

		for (int i = 0; i < mac1.length; i++) {
			strMac1.append(String.format("%02X%s", mac1[i], (i < mac1.length - 1) ? "-" : ""));
		}
		for (int i = 0; i < mac2.length; i++) {
			strMac2.append(String.format("%02X%s", mac2[i], (i < mac2.length - 1) ? "-" : ""));
		}
		String[] strDevices = new String[2];
		strDevices[0] = strMac1.toString();
		strDevices[1] = strMac2.toString();
		return strDevices;
	}

	private void success() {
		JOptionPane.showMessageDialog(null, "Device successfully removed from the user", "Success",
				JOptionPane.INFORMATION_MESSAGE);
		frame.dispose();
		ServerConnection.updateUser(user);
		
	}
}
