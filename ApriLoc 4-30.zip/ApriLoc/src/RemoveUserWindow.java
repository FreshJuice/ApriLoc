import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class RemoveUserWindow {

	JFrame frame;
	JLabel infoLabel, userIDLabel;
	JTextField userIDTF;
	JButton removeButton;

	public RemoveUserWindow() {
		initFrame();
	}

	private void initFrame() {
		JPanel infoGrid = new JPanel(new GridLayout(1, 2));

		frame = new JFrame("Remove User");
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setLayout(new BorderLayout());
		frame.setLocationRelativeTo(null);

		infoLabel = new JLabel(" Remove User ");
		infoLabel.setFont(new Font("Ariel", Font.PLAIN, 28));

		userIDLabel = new JLabel("User ID:");
		userIDTF = new JTextField();

		removeButton = new JButton("Remove");
		removeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int userID;
				try {
					userID = Integer.parseInt(userIDTF.getText());
				} catch (NumberFormatException exception) {
					invalidUserID();
					return;
				}

				User temp = ServerConnection.getUser(userID);
				ArrayList<User> users = ServerConnection.getAllUsers();

				if (temp == null) {
					userNotExist();
					return;
				}

				if (userID == CurrentUser.getUser().getUserID()) {
					cannotDeleteSelf();
					return;
				}

				if (temp.isAdmin()) {
					for (int i = 0; i < users.size(); i++) {
						if (users.get(i).isAdmin() && users.get(i).getUserID() != temp.getUserID()) {
							int choice = JOptionPane.showConfirmDialog(null,
									"Are you sure you would like to remove " + temp.getName() + " with ID: "
											+ temp.getUserID() + " from the system?",
									"Remove User?", JOptionPane.YES_NO_OPTION);
							if (choice == JOptionPane.YES_OPTION) {
								ServerConnection.removeUser(temp.getUserID());
								success();
								frame.dispose();
								break;
							}
						}else if(i == users.size()-1){
							oneAdminError();
						}
					}
					
				}else{
					int choice = JOptionPane.showConfirmDialog(null,
							"Are you sure you would like to remove " + temp.getName() + " with ID: "
									+ temp.getUserID() + " from the system?",
							"Remove User?", JOptionPane.YES_NO_OPTION);
					if (choice == JOptionPane.YES_OPTION) {
						ServerConnection.removeUser(temp.getUserID());
						success();
						frame.dispose();
						
					}
				}

				
			}
		});

		infoGrid.add(userIDLabel);
		infoGrid.add(userIDTF);

		frame.getContentPane().add(infoLabel, BorderLayout.NORTH);
		frame.getContentPane().add(infoGrid, BorderLayout.CENTER);
		frame.getContentPane().add(removeButton, BorderLayout.SOUTH);
		frame.pack();
	}

	private void userNotExist() {
		JOptionPane.showMessageDialog(null, "User ID does not exist", "Error", JOptionPane.ERROR_MESSAGE);
	}

	private void success() {
		JOptionPane.showMessageDialog(null, "User successfully deleted", "Success", JOptionPane.INFORMATION_MESSAGE);
	}
	
	private void invalidUserID() {
		JOptionPane.showMessageDialog(null, "User ID must be a number from 1 - 2147483647", "Error",
				JOptionPane.ERROR_MESSAGE);
	}

	private void cannotDeleteSelf() {
		JOptionPane.showMessageDialog(null, "Can not delete yourself", "Error", JOptionPane.ERROR_MESSAGE);
	}

	private void oneAdminError() {
		JOptionPane.showMessageDialog(null, "System must have at least one administrator", "Error",
				JOptionPane.ERROR_MESSAGE);
	}
}
