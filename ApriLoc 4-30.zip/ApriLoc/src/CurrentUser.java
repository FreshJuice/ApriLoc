
public class CurrentUser{
	
    public static final String ACCOUNT_SID = "ACbdd79893ec4f0c141d24d705ecffe319";
    public static final String AUTH_TOKEN = "3b612e536829c7f2879a50fa167163ea";
	
	private static User currentUser;
	
	public CurrentUser(User user){
		currentUser = user;
	}
	
	public static void setUser(User user){
		currentUser = user;
	}
	
	public static User getUser(){
		return currentUser;
	}
}
