import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;

public class DetailRegistryFormWindow extends JFrame{
	private static final long serialVersionUID = 672879095819277665L;
	JComboBox<String> dropDown;
	String[] privlages;
	JTextArea textArea;
	RegistryForm form;
	
	public DetailRegistryFormWindow(RegistryForm form) {
		// Creates the Frame
		this.setTitle("Grant/Deny Form");
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setVisible(true);
		this.form = form;
		JPanel actionGroup;
		// Main Panel
		JPanel panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;

		// Sub Panel for drop down
		JPanel privlagePanel = new JPanel();
		privlagePanel.setLayout(new GridBagLayout());
		String name  = ServerConnection.getUser(this.form.getUserId()).getName();
				
		JLabel nameLabel = new JLabel(name + " requested: ");
		JLabel selectL = new JLabel();
		privlages = new String[] { "Privlage 1", "Privlage 2", "Privlage 3", "Privlage 4", "Privlage 5" }; // Temporary
																											// privlages
		dropDown = new JComboBox<String>(privlages);
		dropDown.setSelectedItem(this.form.getRequestedPrivlage());
		dropDown.setEnabled(false);
		privlagePanel.add(nameLabel, c);
		c.gridy++;
		privlagePanel.add(selectL, c);
		c.gridx++;
		privlagePanel.add(dropDown);
		c.gridx = 0;
		c.gridy = 0;
		panel.add(privlagePanel);

		// Sub Panel for reason
		JPanel reason = new JPanel();
		TitledBorder tb = BorderFactory.createTitledBorder("Reason");
		reason.setBorder(tb);
		textArea = new JTextArea(5, 30);
		textArea.setText(this.form.getBodyText());
		textArea.setEditable(false);
		reason.add(textArea);
		c.gridy++;
		panel.add(reason, c);

		// Submit Button
		JButton grant = new JButton("Grant");
		JButton deny = new JButton("Deny");
		actionGroup = new JPanel();
		GridLayout gridLay = new GridLayout(0,2);
		actionGroup.setLayout(gridLay);


		if(this.form.isPending()){
			gridLay.setHgap(10);
			grant.addActionListener(new Accept());
			
			c.gridy++;
			c.anchor = GridBagConstraints.CENTER;
			deny.addActionListener(new Deny());
			
			actionGroup.add(deny);
			actionGroup.add(grant);
			
			panel.add(actionGroup,c);
		}
		else{
			if(this.form.isApproved()){
				c.gridy++;
				panel.add(new JLabel("Form has been aproved"),c);
			}
			else{
				c.gridy++;
				panel.add(new JLabel("Form has been denied"),c);
			}
		}
		

		this.add(panel);
		this.pack();

	}

	private class Accept implements ActionListener {

		public void actionPerformed(ActionEvent event) {
			
			form.setPending(false);
			form.setApproved(true);
			ViewRegistryWindow.updateJTable();
			dispose();
			
	}
}
	
	private class Deny implements ActionListener {

		public void actionPerformed(ActionEvent event) {
			form.setPending(false);
			form.setApproved(false);
			ViewRegistryWindow.updateJTable();
			dispose();
			
	}
}

}