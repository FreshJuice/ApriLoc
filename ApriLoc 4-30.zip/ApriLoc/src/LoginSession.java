import java.awt.Frame;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.UUID;

import javax.swing.JOptionPane;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

public class LoginSession {
	private int enteredID;
	private String enteredPassword;
	private String enteredTextCode;
	private String correctTextCode;
	private int numLoginAttempts;

	public LoginSession(int enteredID, String enteredPassword, String enteredTextCode) {
		this.enteredID = enteredID;
		this.enteredPassword = enteredPassword;
		this.enteredTextCode = enteredTextCode;
		this.correctTextCode = generateRandomCode();
	}

	public String generateRandomCode() {
		return UUID.randomUUID().toString().substring(0, 6);
	}

	public boolean isCorrectPassword() {
		return CurrentUser.getUser().isCorrectPassword(enteredPassword);
	}

	public boolean isNewUser() {
		if (CurrentUser.getUser().getPasswordHash().length == 0)
			return true;
		else
			return false;
	}

	public boolean isRegisteredDevice() {
		return CurrentUser.getUser().isCurrentDeviceRegistered();
	}

	private boolean isValidPassword() {
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		byte[] enteredPasswordHash = md.digest(enteredPassword.getBytes());
		if (Arrays.equals(enteredPasswordHash, CurrentUser.getUser().getPasswordHash())) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isValidLogin() {
		if (CurrentUser.getUser() == null)
			return false;
		if (!isRegisteredDevice())
			return false;
		if (!enteredTextCode.equals(correctTextCode))
			return false;
		if (!isValidPassword())
			return false;
		return true;
	}

	public boolean checkExpiredPassword() {
		long oldTime = CurrentUser.getUser().getPasswordTimeStamp();
		long newTime = System.currentTimeMillis();
		double days = ((newTime - oldTime) / 1000.0 / 60.0 / 60.0 / 24.0);
		if (days >= 30) {

			String password = JOptionPane.showInputDialog(null, "Your password has expired, please enter a new one: ",
					"Change Password", JOptionPane.INFORMATION_MESSAGE);
			while (!CurrentUser.getUser().changePassword(password)) {
				password = JOptionPane.showInputDialog(null,
						"Invalid password.\nThe password must follow these requirments:\nAt least 8 characters\nOne uppercase character\nOne lowercase character\nOne digit\nOne non alphanurmeric character\nCan not be your previous password",
						"Change Password", JOptionPane.INFORMATION_MESSAGE);
			}
			return true;
		} else {
			return false;
		}
	}

	public void connectToServer() {

	}

	public void sendTextCode() {
		Twilio.init(CurrentUser.ACCOUNT_SID, CurrentUser.AUTH_TOKEN);

		Message message = Message.creator(new PhoneNumber("+1" + CurrentUser.getUser().getPhoneNumber()), // to
				new PhoneNumber("+15512280345"), // from
				this.correctTextCode).create();
		JOptionPane.showMessageDialog(null, "Text Message Sent", "Text Sent", JOptionPane.INFORMATION_MESSAGE);
	}

	public void setEnteredTextCode(String enteredTextCode) {
		this.enteredTextCode = enteredTextCode;
	}
}
