import java.io.Serializable;
import java.lang.reflect.Array;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;

import javax.swing.plaf.nimbus.NimbusLookAndFeel;

public abstract class User implements Serializable {

	private static final long serialVersionUID = 6692724834742302673L;
	private String name;
	private int userID;
	private byte[] passwordHash;
	private ArrayList<String> priviledgeList;
	private String phoneNumber;
	private boolean isLoggedIn;
	private boolean locked;
	private byte[][] deviceList = new byte[2][6];
	private boolean isAdmin;
	private long passwordTimeStamp;
	private int loginAttempts;
	private long suspendUntilTimeStamp;

	public User(String name, int userID, String phoneNumber, boolean isAdmin) {
		this.name = name;
		this.userID = userID;
		this.phoneNumber = phoneNumber;
		this.passwordHash = "".getBytes();
		this.priviledgeList = new ArrayList<String>();
		this.isLoggedIn = false;
		this.locked = false;
		this.isAdmin = isAdmin;
		this.passwordTimeStamp = -1;
		this.loginAttempts = 0;
	}

	public User(String name, int userID, String phoneNumber, byte[] passwordHash, ArrayList<String> priviledgeList,
			boolean locked, boolean isAdmin, long passwordTimeStamp) {
		this.name = name;
		this.userID = userID;
		this.phoneNumber = phoneNumber;
		this.passwordHash = passwordHash;
		this.priviledgeList = priviledgeList;
		this.isLoggedIn = false;
		this.locked = locked;
		this.isAdmin = isAdmin;
		this.passwordTimeStamp = passwordTimeStamp;
		this.loginAttempts = 0;
	}

	public boolean addDevice(byte[] macAddr) {
		if (macAddr == null)
			return false;
		if (isEmptyByteArray(deviceList[0])) {
			deviceList[0] = macAddr;
			return true;
		} else if (isEmptyByteArray(deviceList[1])) {
			deviceList[1] = macAddr;
			return true;
		} else {
			return false;
		}
	}

	public boolean removeDevice(byte[] macAddr) {
		if (macAddr == null)
			return false;
		if (Arrays.equals(macAddr, deviceList[0])) {
			deviceList[0] = deviceList[1];
			deviceList[1] = "".getBytes();
			return true;
		} else if (Arrays.equals(macAddr, deviceList[1])) {
			deviceList[1] = "".getBytes();
			return true;
		}
		return false;
	}

	public void addCurrentDevice() {
		try {
			Enumeration<NetworkInterface> ni = NetworkInterface.getNetworkInterfaces();
			byte[] macBytes = ni.nextElement().getHardwareAddress();
			addDevice(macBytes);
		} catch (SocketException e) {
			e.printStackTrace();
		}
	}

	public static byte[] getCurrentDevice() {
		try {
			Enumeration<NetworkInterface> ni = NetworkInterface.getNetworkInterfaces();
			byte[] macBytes = ni.nextElement().getHardwareAddress();
			return macBytes;
		} catch (SocketException e) {
			e.printStackTrace();
		}
		return null;
	}

	private boolean isEmptyByteArray(byte[] array) {
		if (array == null)
			return true;
		for (byte num : array) {
			if (num != 0)
				return false;
		}
		return true;
	}

	public boolean isRegisteredDevice(byte[] macAddr) {
		if (Arrays.equals(deviceList[0], macAddr)) {
			return true;
		} else if (Arrays.equals(deviceList[1], macAddr)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isCurrentDeviceRegistered() {
		try {
			Enumeration<NetworkInterface> ni = NetworkInterface.getNetworkInterfaces();
			while (ni.hasMoreElements()) {
				byte[] tempAddr = ni.nextElement().getHardwareAddress();
				if (Arrays.equals(tempAddr, deviceList[0]) || Arrays.equals(tempAddr, deviceList[1]))
					return true;
			}
		} catch (SocketException e) {
			e.printStackTrace();
		}
		return false;
	}

	public byte[][] getDeviceList() {
		return this.deviceList;
	}

	public void addPriviledge(String priviledge) {
		priviledgeList.add(priviledge);
	}

	public String removePriviledge(String priviledge) {
		for (int i = 0; i < priviledgeList.size(); i++) {
			if (priviledgeList.get(i).equals(priviledge)) {
				String oldPriviledge = priviledgeList.get(i);
				priviledgeList.remove(i);
				return oldPriviledge;
			}
		}
		return null;
	}

	public void forceChangePassword(String password) {
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		byte[] newPassword = md.digest(password.getBytes());
		passwordHash = newPassword;
		passwordTimeStamp = System.currentTimeMillis();
	}

	public boolean changePassword(String password) {
		if (!isStrongPassword(password)) {
			return false;
		}
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		byte[] newPassword = md.digest(password.getBytes());
		if (Arrays.equals(passwordHash, newPassword)) {
			return false;
		} else {
			passwordHash = newPassword;
			passwordTimeStamp = System.currentTimeMillis();
			return true;
		}
	}

	public boolean isCorrectPassword(String password) {
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		byte[] hashedPassword = md.digest(password.getBytes());
		if (Arrays.equals(passwordHash, hashedPassword)) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean isStrongPassword(String password) {
		if (password.length() < 8)
			return false;
		if (password.toLowerCase().equals(password))
			return false;
		if (password.toUpperCase().equals(password))
			return false;
		if (!password.matches(".*\\d.*")) // digit
			return false;
		if (!password.matches(".*\\W.*")) // non-word character
			return false;
		return true;
	}

	public long getSuspendUntilTimeStamp() {
		return suspendUntilTimeStamp;
	}

	public boolean isSuspended() {
		return getSuspendUntilTimeStamp() > System.currentTimeMillis();
	}

	public void suspendUser(long minutes) {
		this.suspendUntilTimeStamp = System.currentTimeMillis() + minutes * 60L * 1000L;
	}

	public boolean isLoggedIn() {
		return isLoggedIn;
	}

	public void setLoggedIn(boolean isLoggedIn) {
		this.isLoggedIn = isLoggedIn;
	}

	public int getLoginAttempts() {
		return loginAttempts;
	}

	public void setLoginAttempts(int loginAttempts) {
		this.loginAttempts = loginAttempts;
	}

	public boolean isLocked() {
		return locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public long getPasswordTimeStamp() {
		return passwordTimeStamp;
	}

	public void setPasswordTimeStamp(long passwordTimeStamp) {
		this.passwordTimeStamp = passwordTimeStamp;
	}

	public boolean setPhoneNumber(String phoneNumber) {
		if (!phoneNumber.matches(".*\\D.*")) {
			this.phoneNumber = phoneNumber;
			return true;
		} else {
			return false;
		}
	}

	public String getPhoneNumber() {
		return this.phoneNumber;
	}

	public byte[] getPasswordHash() {
		return this.passwordHash;
	}

	public void setPasswordHash(byte[] passwordHash) {
		this.passwordHash = passwordHash;
	}

	public int getUserID() {
		return this.userID;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	public String toString() {
		return "Name: " + this.name + "\nUser ID: " + this.userID + "\nPassword Hash: " + this.passwordHash
				+ "\nPhone Number: " + this.phoneNumber + "\nLocked: " + this.locked + "\nAdmin: " + this.isAdmin
				+ "\nLogged In:" + this.isLoggedIn + "\n";
	}
}
