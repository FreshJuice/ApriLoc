import java.util.ArrayList;

public class Administrator extends User {

	private static final long serialVersionUID = 2848509183519282624L;

	public Administrator(String name, int userID, String phoneNumber) {
		super(name, userID, phoneNumber, true);
	}

	public Administrator(String name, int userID, String phoneNumber, byte[] passwordHash,
			ArrayList<String> priviledgeList, boolean locked, long passwordTimeStamp) {
		super(name, userID, phoneNumber, passwordHash, priviledgeList, locked, true, passwordTimeStamp);
	}

	public boolean registerDevice(byte[] macAddr, int userID) {
		return UserCollections.getUser(userID).addDevice(macAddr);
	}

	public void lockUserAccount(int userID) {
		UserCollections.getUser(userID).setLocked(true);
	}

	public void unlockUserAccount(int userID) {
		UserCollections.getUser(userID).setLocked(false);
	}

	public boolean addUserAccount(String name, int userID, String phoneNumber) {
		return UserCollections.addUser(new UserAccount(name, userID, phoneNumber));
	}

	public boolean addAdminAccount(String name, int userID, String phoneNumber) {
		return UserCollections.addUser(new Administrator(name, userID, phoneNumber));
	}

	public boolean suspendUser(int userID, int seconds) {
		User suspendUser = UserCollections.getUser(userID);
		if (suspendUser == null)
			return false;
		suspendUser.suspendUser(System.currentTimeMillis() + seconds * 1000);
		return true;
	}
}
