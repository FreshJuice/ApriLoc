import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JToolBar;
import javax.swing.border.Border;

public class MainPanel extends JPanel {

	private static final long serialVersionUID = 2949687444255909471L;
	MainPanel thisObj = this;
	JPanel leftBar, middleBar, rightBar;
	JToolBar toolBar;
	JPopupMenu settingsMenu;
	JButton optionsButton, loginButton;
	JLabel userInfo;
	// User loggedInUser;

	public MainPanel() {
		this.setLayout(new BorderLayout());
		initializeButtons();
		initializePopups(false);
		setBackground(ColorScheme.BACKGROUND);
		toolBar = new JToolBar() {
			private static final long serialVersionUID = -6004450648021907506L;

			@Override
			public void setBorder(Border border) {

			}
		};
		toolBar.setFloatable(false);
		toolBar.setLayout(new GridLayout(1, 3));
		toolBar.setBackground(ColorScheme.BACKGROUND);

		leftBar = new JPanel(new BorderLayout());
		rightBar = new JPanel(new BorderLayout());
		middleBar = new JPanel(new BorderLayout());

		leftBar.add(loginButton, BorderLayout.WEST);
		leftBar.setBackground(ColorScheme.BACKGROUND);
		rightBar.add(optionsButton, BorderLayout.EAST);
		rightBar.setBackground(ColorScheme.BACKGROUND);
		middleBar.add(new LiveClock(), BorderLayout.CENTER);
		middleBar.setBackground(ColorScheme.BACKGROUND);

		toolBar.add(leftBar, BorderLayout.WEST);
		toolBar.add(middleBar, BorderLayout.NORTH);
		toolBar.add(rightBar, BorderLayout.EAST);
		add(toolBar, BorderLayout.NORTH);
	}

	public void loggedIn() {
		initializePopups(true);
		leftBar.removeAll();
		userInfo = new JLabel("Logged in as " + CurrentUser.getUser().getName());
		userInfo.setForeground(ColorScheme.TEXT);
		userInfo.setBackground(ColorScheme.BACKGROUND);
		leftBar.add(userInfo, BorderLayout.WEST);
		leftBar.repaint();
		this.repaint();
	}

	public void loggedOut() {
		initializePopups(false);
		leftBar.removeAll();
		leftBar.add(loginButton);
		leftBar.add(loginButton, BorderLayout.WEST);
		leftBar.repaint();
		this.repaint();
		CurrentUser.getUser().setLoggedIn(false);
		ServerConnection.updateUser(CurrentUser.getUser());
		CurrentUser.setUser(null);
	}

	public void initializeButtons() {
		optionsButton = new JButton("Options") {

			private static final long serialVersionUID = -6787308257251688115L;

			@Override
			public void setBorder(Border border) {
			}
		};
		optionsButton.setBackground(ColorScheme.COMPONENT);
		optionsButton.setForeground(ColorScheme.TEXT);
		optionsButton.setPreferredSize(new Dimension(65, 25));
		optionsButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				settingsMenu.show(optionsButton, optionsButton.getBounds().x,
						optionsButton.getBounds().y + optionsButton.getBounds().height);
			}
		});

		loginButton = new JButton("Login") {
			private static final long serialVersionUID = -5303291251309938394L;

			@Override
			public void setBorder(Border border) {
			}
		};
		loginButton.setBackground(ColorScheme.COMPONENT);
		loginButton.setForeground(ColorScheme.TEXT);
		loginButton.setPreferredSize(new Dimension(45, 25));
		loginButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new LoginWindow(thisObj);
			}
		});
	}

	public void initializePopups(boolean loggedIn) {
		settingsMenu = new JPopupMenu();
		if (loggedIn) {
			settingsMenu.add(new JMenuItem(new AbstractAction("Change Password") {
				private static final long serialVersionUID = -7317936454588671908L;

				public void actionPerformed(ActionEvent e) {
					if (CurrentUser.getUser().isAdmin())
						new PasswordAdminWindow();
					else
						new PasswordUserWindow();
				}
			}));
			settingsMenu.add(new JMenuItem(new AbstractAction("Sumbit Registry Form") {
				private static final long serialVersionUID = -5546349463890374921L;

				public void actionPerformed(ActionEvent e) {
					new SubmitRegistryFormWindow();
				}
			}));
			if (CurrentUser.getUser().isAdmin()) {
				settingsMenu.add(new JMenuItem(new AbstractAction("View Users") {
					private static final long serialVersionUID = -5546349463890374921L;

					public void actionPerformed(ActionEvent e) {
						new ViewUsersWindow();
					}
				}));
			}
			settingsMenu.add(new JMenuItem(new AbstractAction("Logout") {
				private static final long serialVersionUID = -5546349463890374921L;

				public void actionPerformed(ActionEvent e) {
					loggedOut();
				}
			}));
		}
		settingsMenu.add(new JMenuItem(new AbstractAction("Quit") {
			private static final long serialVersionUID = 4220617683438665126L;

			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		}));

	}

}
