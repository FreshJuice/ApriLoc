import java.io.IOException;

public class Test {

	public static void main(String[] args) {
		Server server = null;
		
		try {
			server = new Server(5555);
		} catch (IOException e) {
			System.err.println("Can not start server, is port in use? Already running?");
			return;
		}
//		Administrator me = new Administrator("Christian Laemmerhirt", 1, "9089142196");
//		me.addCurrentDevice();
//		me.forceChangePassword("1");
//		UserCollections.addUser(me);
//		UserCollections.addUser(new UserAccount("John Smith", 2, "9085556789"));
		System.out.println("SERVER - Listening");
		server.listenForClients();
		
		
	}

}
