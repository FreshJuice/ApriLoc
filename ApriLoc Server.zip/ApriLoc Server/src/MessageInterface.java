import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class MessageInterface {
	private Socket client;
	private User loggedInUser;

	private ObjectOutputStream objectOutputStream;
	private static ObjectInputStream objectInputStream;

	private String regFormPriv;
	private String regFormBody;

	public MessageInterface(Socket client) {
		this.client = client;
		try {
			objectOutputStream = new ObjectOutputStream(client.getOutputStream());
			objectInputStream = new ObjectInputStream(client.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
		listenForMessages();
	}

	private void sendMessage(String message) {

		try {
			objectOutputStream.writeObject(new String(message));
			objectOutputStream.flush();
		} catch (IOException e) {
			disconnect();
			e.printStackTrace();
		}
	}

	private void sendInteger(int num) {

		try {
			objectOutputStream.writeInt(num);
			;
			objectOutputStream.flush();
		} catch (IOException e) {
			disconnect();
			e.printStackTrace();
		}

	}

	private void handleMessages(String message) {
		String messageCode = message.substring(0, 8);
		message = message.substring(8);
		if (messageCode.equals("user----")) {
			User user = UserCollections.getUser(Integer.parseInt(message));
			sendObj(user);
		} else if (messageCode.equals("login---")) {
			String successful = message.substring(0, 1);
			String userID = message.substring(1, message.length() - 1);
			String numLoginAttemps = message.substring(message.length() - 1);

			User user = UserCollections.getUser(Integer.parseInt(userID));

			LogEntry logEntry = new LogEntry(System.currentTimeMillis(), Integer.parseInt(userID),
					Integer.parseInt(numLoginAttemps));

			UserCollections.addLogEntry(logEntry);

			if (successful.equals("t")) {
				user.setLoggedIn(true);
				loggedInUser = user;
			}
		} else if (messageCode.equals("regForm1")) {
			regFormPriv = message;
		} else if (messageCode.equals("regForm2")) {
			regFormBody = message;
		} else if (messageCode.equals("regForm3")) {
			UserCollections.addRegistryForm(new RegistryForm(Integer.parseInt(message), regFormPriv, regFormBody));
		} else if (messageCode.equals("allUsers")) {
			sendInteger(UserCollections.getUserList().size());
			for (int i = 0; i < UserCollections.getUserList().size(); i++) {
				sendObj(UserCollections.getUserList().get(i));
			}
		} else if (messageCode.equals("update--")) {
			User user = (User) recieveObj();
			for (int i = 0; i < UserCollections.getUserList().size(); i++) {
				if (UserCollections.getUserList().get(i).getUserID() == user.getUserID()) {
					UserCollections.getUserList().remove(i);
					UserCollections.addUser(user);
				}
			}
		} else if (messageCode.equals("newAdmin")) {
			Administrator admin = (Administrator) recieveObj();
			UserCollections.addUser(admin);
		} 
	}

	private static Object recieveObj() {
		try {
			return objectInputStream.readObject();
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private void sendObj(Object obj) {
		try {
			objectOutputStream.writeObject(obj);
			objectOutputStream.flush();
		} catch (IOException e) {
			disconnect();
			e.printStackTrace();
		}
	}

	private void listenForMessages() {
		new Thread() {
			@Override
			public void run() {
				ObjectInputStream asd = objectInputStream;
				while (true) {
					try {
						System.out.println("Waiting for message");
						String message = asd.readUTF();
						System.out.println("Receieved Message: " + message + "\n");
						if (message == null) {
							disconnect();
							break;
						} else {
							handleMessages(message);
						}
					} catch (IOException e) {
						disconnect();
						break;
					}
				}

				super.run();
			}
		}.start();
	}

	private void disconnect() {
		try {
			loggedInUser.setLoggedIn(false);
			UserCollections.removeUser(loggedInUser.getUserID());
			UserCollections.addUser(loggedInUser);
		} catch (Exception e) {

		}
		System.out.println(UserCollections.getUser(2).isLoggedIn());
		Server.disconnect(client);
	}
}
