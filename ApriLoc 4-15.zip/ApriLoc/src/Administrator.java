import java.util.ArrayList;

public class Administrator extends User {

	private static final long serialVersionUID = 2848509183519282624L;

	public Administrator(String name, int userID, String phoneNumber) {
		super(name, userID, phoneNumber, true);
	}

	public Administrator(String name, int userID, String phoneNumber, byte[] passwordHash,
			ArrayList<String> priviledgeList, boolean locked, long passwordTimeStamp) {
		super(name, userID, phoneNumber, passwordHash, priviledgeList, locked, true, passwordTimeStamp);
	}
}
