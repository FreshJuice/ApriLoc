import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class CreateUserWindow implements ActionListener {

	JFrame frame;
	JLabel titleLabel, userIDLabel, nameLabel, phoneLabel, isAdminLabel;
	JTextField userIDTF, nameTF, phoneTF;
	JRadioButton isAdminYes, isAdminNo;
	JButton finishButton;

	public CreateUserWindow() {
		initFrame();
	}

	public void initFrame() {
		JPanel infoGrid = new JPanel(new GridLayout(4, 2));
		JPanel buttonsPanel = new JPanel(new GridLayout(1, 2));

		frame = new JFrame("Create New User");
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setLayout(new BorderLayout());
		frame.setLocationRelativeTo(null);

		titleLabel = new JLabel(" Create New User: ");
		titleLabel.setFont(new Font("Ariel", Font.PLAIN, 28));

		userIDLabel = new JLabel("User ID:");
		userIDLabel.setFont(new Font("Ariel", Font.PLAIN, 14));

		userIDTF = new JTextField();

		phoneLabel = new JLabel("Phone Number:");
		phoneLabel.setFont(new Font("Ariel", Font.PLAIN, 14));

		phoneTF = new JTextField();

		nameLabel = new JLabel("Name:");
		nameLabel.setFont(new Font("Ariel", Font.PLAIN, 14));

		nameTF = new JTextField();

		isAdminLabel = new JLabel("Is Admin?");
		isAdminLabel.setFont(new Font("Ariel", Font.PLAIN, 14));

		isAdminYes = new JRadioButton("Yes");
		isAdminYes.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				isAdminNo.setSelected(false);
				isAdminYes.setSelected(true);
			}
		});

		isAdminNo = new JRadioButton("No");
		isAdminNo.setSelected(true);
		isAdminNo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				isAdminNo.setSelected(true);
				isAdminYes.setSelected(false);
			}
		});
		finishButton = new JButton("Finish");
		finishButton.addActionListener(this);

		buttonsPanel.add(isAdminYes);
		buttonsPanel.add(isAdminNo);

		infoGrid.add(isAdminLabel);
		infoGrid.add(buttonsPanel);
		infoGrid.add(userIDLabel);
		infoGrid.add(userIDTF);
		infoGrid.add(nameLabel);
		infoGrid.add(nameTF);
		infoGrid.add(phoneLabel);
		infoGrid.add(phoneTF);

		frame.getContentPane().add(titleLabel, BorderLayout.NORTH);
		frame.getContentPane().add(infoGrid, BorderLayout.CENTER);
		frame.getContentPane().add(finishButton, BorderLayout.SOUTH);

		frame.pack();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		boolean isAdmin = isAdminYes.isSelected();
		int userID;
		String name = nameTF.getText();
		String phoneNumber = phoneTF.getText();

		try {
			userID = Integer.parseInt(userIDTF.getText());
		} catch (NumberFormatException exception) {
			invalidUserID();
			return;
		}

		User temp = ServerConnection.getUser(userID);

		if (temp != null) {
			userIDTaken();
			return;
		}

		try {
			Long.parseLong(phoneNumber);
		} catch (NumberFormatException exception) {
			invalidPhoneNumber();
			return;
		}

		if (phoneNumber.length() != 10) {
			invalidPhoneNumber();
			return;
		}

		User user;

		if (isAdmin) {
			user = new Administrator(name, userID, phoneNumber);
			ServerConnection.setUpNewAdmin(user);
		} else {
			user = new UserAccount(name, userID, phoneNumber);
			ServerConnection.setUpNewUser(user);
		}
		
		
		frame.dispose();
	}

	private void userIDTaken() {
		JOptionPane.showMessageDialog(null, "User ID is already taken", "Error", JOptionPane.ERROR_MESSAGE);
	}

	private void invalidUserID() {
		JOptionPane.showMessageDialog(null, "User ID must be a number from 1 - 2147483647", "Error",
				JOptionPane.ERROR_MESSAGE);
	}

	private void invalidPhoneNumber() {
		JOptionPane.showMessageDialog(null, "Invalid Phone Number.\nMust contain 10 digits.", "Error",
				JOptionPane.ERROR_MESSAGE);
	}
}
