import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class ServerConnection extends Socket {
	private static Socket server;

	private static ObjectInputStream objectInputStream;
	private static ObjectOutputStream objectOutputStream;

	public static void connectToServer(String ip_addr, int port) {
		try {
			server = new Socket(ip_addr, port);

			objectInputStream = new ObjectInputStream(server.getInputStream());
			objectOutputStream = new ObjectOutputStream(server.getOutputStream());
			OnNewConnection(server);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void OnNewConnection(Socket server) {
		System.out.println("CLIENT - Connected to " + server.getInetAddress().getHostAddress());
	}

	public static User getUser(int userID) {
		sendMessage("user----" + userID);
		User user = (User) recieveObj();
		return user;
	}

	public static ArrayList<RegistryForm> getRegistryFormList(){
		sendMessage("getReg--");
		ArrayList<RegistryForm> registryForms = new ArrayList<RegistryForm>();
		try {
			registryForms = (ArrayList<RegistryForm>) objectInputStream.readObject();
		} catch (ClassNotFoundException | IOException e) {
			return registryForms;
		}
		return registryForms;
		
	}
	
	public static ArrayList<User> getAllUsers() {
		sendMessage("allUsers");
		int numUsers = 0;
		try {
			numUsers = objectInputStream.readInt();
		} catch (NumberFormatException | IOException e1) {
			System.err.println("Error in getAllUsers() in Server Connection, ArrayList not an integer");
		}
		ArrayList<User> tempUsers = new ArrayList<User>();
		try {
			while (tempUsers.size() != numUsers)
				tempUsers.add((User) objectInputStream.readObject());
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
		return tempUsers;
	}

	public static ArrayList<RegistryForm> getRegistryForms(){
		sendMessage("getRegFm");
		int numForms = 0;
		try {
			numForms = objectInputStream.readInt();
		} catch (NumberFormatException | IOException e1) {
			System.err.println("Error in getRegistryForms() in Server Connection, ArrayList not an integer");
		}
		ArrayList<RegistryForm> tempForms = new ArrayList<RegistryForm>();
		try {
			while (tempForms.size() != numForms)
				tempForms.add((RegistryForm) objectInputStream.readObject());
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
		return tempForms;
	}
	
	public static void updateUser(User user) {
		sendMessage("update--" + user.getUserID());
		sendObj(user);
	}
	
	public static void removeUser(int userID) {
		sendMessage("rmuser--" + userID);
	}
	
	public static void logout(int userID) {
		sendMessage("logout--" + userID);
	}
	
	public static void sendLoginAttempt(boolean successful) {
		System.out.println("LOGGING IN " + CurrentUser.getUser().getName());
		System.out.println("SUCCESSFUL: " + successful);
		sendMessage("login---" + (successful + "").substring(0, 1) + CurrentUser.getUser().getUserID()
				+ CurrentUser.getUser().getLoginAttempts());
	}

	public static void sendRegistryForm(Integer userID, String privlage, String bodyText) {
		sendMessage("regForm1" + privlage);
		sendMessage("regForm2" + bodyText);
		sendMessage("regForm3" + userID);
	}

	public static void setUpNewAdmin(User user) {
		sendMessage("newAdmin");
		sendObj(user);
	}
	
	public static void setUpNewUser(User user) {
		sendMessage("newUser-");
		sendObj(user);
	}
	
	private static void sendMessage(String message) {
		try {
			objectOutputStream.writeUTF(message);
			objectOutputStream.flush();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Lost Connection To Server", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	private static void sendObj(Object obj) {
		try {
			objectOutputStream.writeObject(obj);
			objectOutputStream.flush();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Lost Connection To Server", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	private static Object recieveObj() {
		try {
			return objectInputStream.readObject();
		} catch (ClassNotFoundException | IOException e) {
			JOptionPane.showMessageDialog(null, "Lost Connection To Server", "Error", JOptionPane.ERROR_MESSAGE);
		}
		return null;
	}
}
