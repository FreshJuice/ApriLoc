import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class PasswordAdminWindow extends JFrame{

	private static final long serialVersionUID = 7963106197821634500L;
	JFrame thisFrame = this;
	JPasswordField newPasswordTF, confirmPasswordTF;
	JLabel newPasswordLabel, confirmPasswordLabel, userIDLabel;
	JTextField userIDTF;
	JButton doneButton;
	JPanel fieldsPanel;
	
	public PasswordAdminWindow(){
		this.setTitle("Change Password");
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setLayout(new BorderLayout());
		this.setLocationRelativeTo(null);
		newPasswordLabel = new JLabel("New Password: ");
		newPasswordTF = new JPasswordField();
		confirmPasswordLabel = new JLabel("Confirm Password: ");
		confirmPasswordTF = new JPasswordField();
		doneButton = new JButton("Done");
		fieldsPanel = new JPanel(new GridLayout(3, 2));
		userIDLabel = new JLabel("User ID");
		userIDTF = new JTextField();
		doneButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(!validUserID()){
					invalidUserID();
					return;
				}
				if(!passwordsMatch()){
					passwordsDontMatch();
					return;
				}
				
				String password = getPassword(newPasswordTF);
				User user = ServerConnection.getUser(getUserIDInt());
				user.forceChangePassword(password);
				CurrentUser.setUser(user);
				ServerConnection.updateUser(user);	
				thisFrame.dispose();
			}
		});
		newPasswordTF.setPreferredSize(new Dimension(155, 19));
		
		fieldsPanel.add(userIDLabel);
		fieldsPanel.add(userIDTF);
		fieldsPanel.add(newPasswordLabel);
		fieldsPanel.add(newPasswordTF);
		fieldsPanel.add(confirmPasswordLabel);
		fieldsPanel.add(confirmPasswordTF);
		this.add(fieldsPanel, BorderLayout.NORTH);
		this.add(doneButton, BorderLayout.SOUTH);
		pack();
	}
	
	private boolean validUserID(){
		int userID = getUserIDInt();
		if(userID == -1)
			return false;
		
		if(ServerConnection.getUser(userID) == null)
			return false;
		else
			return true;
	}
	
	private int getUserIDInt(){
		int userID = -1;
		try{
			userID = Integer.parseInt(userIDTF.getText());
		}catch (Exception e) {
			
		}
		return userID;
	}
	
	private String getPassword(JPasswordField passwordField){
		char[] charPassword = passwordField.getPassword();
		String strPassword = "";
		for(char character : charPassword)
			strPassword += character;
		return strPassword;
	}
	
	private boolean passwordsMatch(){
		String newPassword = getPassword(newPasswordTF);
		String confirmPassword = getPassword(confirmPasswordTF);
		return newPassword.equals(confirmPassword);
	}
	
	private void passwordsDontMatch(){
		JOptionPane.showMessageDialog(this,
				"Passwords Don't Match", "Error", JOptionPane.ERROR_MESSAGE);
	}	
	
	private void invalidUserID(){
		JOptionPane.showMessageDialog(this,
				"Invalid User ID", "Error", JOptionPane.ERROR_MESSAGE);
	}
}
