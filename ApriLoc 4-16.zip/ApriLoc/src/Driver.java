import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Driver {

	public static void main(String[] args) {
		final String ip_addr = "127.0.0.1"; // IP Address of server
		final int port = 5555; // port of the server

		try {
			ServerConnection.connectToServer("127.0.0.1", 5555);
		} catch (Exception e) {
			System.err.println("Unable to connect");
		}
		
		if (ServerConnection.getAllUsers().size() == 0) {
			new WelcomeWindow();
		} else {
			new MainWindow();
		}		
	}

}