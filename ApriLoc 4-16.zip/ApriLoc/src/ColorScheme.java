import java.awt.Color;

public class ColorScheme {
	final public static Color BACKGROUND = new Color(45, 45, 45);
	final public static Color COMPONENT = new Color(45, 45, 45);
	final public static Color TEXT = new Color(145, 145, 145);
}
