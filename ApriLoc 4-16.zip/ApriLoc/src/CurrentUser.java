
public class CurrentUser{
	
	private static User currentUser;
	
	public CurrentUser(User user){
		currentUser = user;
	}
	
	public static void setUser(User user){
		currentUser = user;
	}
	
	public static User getUser(){
		return currentUser;
	}
}
