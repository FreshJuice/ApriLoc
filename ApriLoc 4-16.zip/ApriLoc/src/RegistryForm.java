import java.io.Serializable;

public class RegistryForm implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1322337396442548097L;
	private int userID;
	private String requestedPrivlage;
	private String bodyText;

	public RegistryForm(int userID, String requestedPrivlage, String bodyText) {
		requestedPrivlage = this.requestedPrivlage;
		bodyText = this.bodyText;
	}

	public int getUserId() {
		return this.userID;
	}

	public String getRequestedPrivlage() {
		return this.requestedPrivlage;
	}

	public String getBodyText() {
		return this.getBodyText();
	}
}
