import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class WelcomeWindow {

	// Name Frame
	JFrame nameFrame, passwordFrame, phoneFrame;
	JLabel welcomeLabel, infoLabel, firstNameLabel, lastNameLabel;
	JTextField firstNameTF, lastNameTF;
	JButton continueButton;
	String firstName, lastName, phoneNumber;
	JPanel fieldsPanel, labelPanel;

	// Password Frame
	JLabel passwordLabel, passwordTFLabel, confirmPasswordTFLabel;
	String password, confirmPassword;
	JPasswordField passwordTF, confirmPasswordTF;

	// Phone Frame
	JLabel phoneLabel, phoneTFLabel;
	JTextField phoneNumberTF;

	public WelcomeWindow() {
		 initNameFrame();
	}

	private void initNameFrame() {
		nameFrame = new JFrame("ApriLoc");
		nameFrame.setVisible(true);
		nameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		nameFrame.setLayout(new BorderLayout());
		nameFrame.setLocationRelativeTo(null);

		welcomeLabel = new JLabel("Welcome to ApriLoc!");
		welcomeLabel.setFont(new Font("Ariel", Font.PLAIN, 28));
		welcomeLabel.setAlignmentY(Component.CENTER_ALIGNMENT);

		infoLabel = new JLabel("No Users Detected, Create Administrator Account: ");
		infoLabel.setFont(new Font("Ariel", Font.PLAIN, 14));
		infoLabel.setAlignmentY(Component.CENTER_ALIGNMENT);

		firstNameLabel = new JLabel("First Name: ");
		lastNameLabel = new JLabel("Last Name: ");
		continueButton = new JButton("Continue");

		labelPanel = new JPanel(new GridLayout(2, 1));
		labelPanel.add(welcomeLabel);
		labelPanel.add(infoLabel);

		firstNameTF = new JTextField();
		lastNameTF = new JTextField();

		fieldsPanel = new JPanel(new GridLayout(2, 2));
		fieldsPanel.add(firstNameLabel);
		fieldsPanel.add(firstNameTF);
		fieldsPanel.add(lastNameLabel);
		fieldsPanel.add(lastNameTF);

		continueButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				nameFrameContinue();
			}
		});

		nameFrame.add(labelPanel, BorderLayout.NORTH);
		nameFrame.add(fieldsPanel, BorderLayout.CENTER);
		nameFrame.add(continueButton, BorderLayout.SOUTH);
		nameFrame.pack();
	}

	private void initPasswordFrame() {
		passwordFrame = new JFrame("ApriLoc");
		passwordFrame.setVisible(true);
		passwordFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		passwordFrame.setLayout(new BorderLayout());
		passwordFrame.setLocationRelativeTo(null);

		passwordLabel = new JLabel("Enter Password: ");
		passwordLabel.setFont(new Font("Ariel", Font.PLAIN, 28));
		passwordLabel.setAlignmentY(Component.CENTER_ALIGNMENT);

		passwordTFLabel = new JLabel("Password: ");
		confirmPasswordTFLabel = new JLabel("Confirm Password: ");
		continueButton = new JButton("Continue");

		passwordTF = new JPasswordField();
		confirmPasswordTF = new JPasswordField();

		fieldsPanel = new JPanel(new GridLayout(2, 2));
		fieldsPanel.add(passwordTFLabel);
		fieldsPanel.add(passwordTF);
		fieldsPanel.add(confirmPasswordTFLabel);
		fieldsPanel.add(confirmPasswordTF);

		continueButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				passwordFrameContinue();
			}
		});

		passwordFrame.add(passwordLabel, BorderLayout.NORTH);
		passwordFrame.add(fieldsPanel, BorderLayout.CENTER);
		passwordFrame.add(continueButton, BorderLayout.SOUTH);
		passwordFrame.pack();
	}

	private void initPhoneFrame() {
		phoneFrame = new JFrame("ApriLoc");
		phoneFrame.setVisible(true);
		phoneFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		phoneFrame.setLayout(new BorderLayout());
		phoneFrame.setLocationRelativeTo(null);

		phoneLabel = new JLabel("Enter Phone Number (no dashes):");
		phoneLabel.setFont(new Font("Ariel", Font.PLAIN, 20));
		phoneLabel.setAlignmentY(Component.CENTER_ALIGNMENT);

		phoneTFLabel = new JLabel("Phone Number: ");
		
		phoneNumberTF = new JTextField();
		
		continueButton = new JButton("Finish");

		fieldsPanel = new JPanel(new GridLayout(1,2));
		fieldsPanel.add(phoneTFLabel);
		fieldsPanel.add(phoneNumberTF);

		continueButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				phoneFrameContinue();
			}
		});

		phoneFrame.add(phoneLabel, BorderLayout.NORTH);
		phoneFrame.add(fieldsPanel, BorderLayout.CENTER);
		phoneFrame.add(continueButton, BorderLayout.SOUTH);
		phoneFrame.pack();
	}

	private void nameFrameContinue() {
		firstName = firstNameTF.getText();
		lastName = lastNameTF.getText();

		if (firstName.matches(".*\\d.*") || lastName.matches(".*\\d.*") || firstName.matches(".*\\W.*")
				|| lastName.matches(".*\\W.*")) {
			JOptionPane.showMessageDialog(nameFrame, "Name can only contain letters", "Invalid Name",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		nameFrame.dispose();
		initPasswordFrame();
	}

	private void passwordFrameContinue() {
		password = "";
		confirmPassword = "";

		for (char letter : passwordTF.getPassword()) {
			password += letter;
		}

		for (char letter : confirmPasswordTF.getPassword()) {
			confirmPassword += letter;
		}

		if (!password.equals(confirmPassword)) {
			passwordsDontMatch();
			return;
		}

		if (!User.isStrongPassword(password)) {
			showRequirements();
			return;
		}

		passwordFrame.dispose();
		initPhoneFrame();
	}

	private void phoneFrameContinue(){
		phoneNumber = phoneNumberTF.getText();
		
		try{
			Long.parseLong(phoneNumber);
		}catch(NumberFormatException e){
			invalidPhoneNumber();
			return;
		}
		
		if(phoneNumber.length() != 10){
			invalidPhoneNumber();
			return;
		}
		
		phoneFrame.dispose();
		Administrator administrator = new Administrator(firstName + " " + lastName, 1, phoneNumber);
		administrator.forceChangePassword(password);
		administrator.addCurrentDevice();
		ServerConnection.setUpNewAdmin(administrator);
	}
	
	private void showRequirements() {
		JOptionPane.showMessageDialog(passwordFrame,
				"Invalid password.\nThe password must follow these requirments:\nAt least 8 characters\nOne uppercase character\nOne lowercase character\nOne digit\nOne non alphanumeric character\nCan not be your previous password",
				"Error", JOptionPane.ERROR_MESSAGE);
	}
	
	private void invalidPhoneNumber() {
		JOptionPane.showMessageDialog(phoneFrame, "Invalid Phone Number.\nMust contain 10 digits.", "Error", JOptionPane.ERROR_MESSAGE);
	}
	
	private void passwordsDontMatch() {
		JOptionPane.showMessageDialog(passwordFrame, "Passwords Don't Match.", "Error", JOptionPane.ERROR_MESSAGE);
	}
}
