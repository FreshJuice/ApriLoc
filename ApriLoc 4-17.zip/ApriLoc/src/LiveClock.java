import java.time.LocalDateTime;

import javax.swing.JLabel;

public class LiveClock extends JLabel {
	private static final long serialVersionUID = 3329135166431499090L;
	LocalDateTime time;
	JLabel thisLabel = this;
	String dateText;

	public LiveClock() {
		thisLabel.setForeground(ColorScheme.TEXT);
		new Thread() {
			@Override
			public void run() {
				while (true) {
					time = LocalDateTime.now();
					formatDate();
					thisLabel.setText(dateText);
					try {
						Thread.sleep((60 - time.getSecond()) * 1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}.start();
	}

	private void formatDate() {
		dateText = "";

		dateText += time.getDayOfWeek().toString().substring(0, 1)
				+ time.getDayOfWeek().toString().substring(1).toLowerCase();
		dateText += ", " + time.getDayOfMonth() + " ";
		dateText += time.getMonth().toString().substring(0, 1) + time.getMonth().toString().substring(1).toLowerCase();
		dateText += " " + time.getYear() + ", ";
		if (time.getHour() > 12) {
			dateText += (time.getHour() - 12) + ":";
			if (time.getMinute() < 10) {
				dateText += "0" + time.getMinute();
			} else {
				dateText += time.getMinute();
			}
			dateText += "PM";
		} else {
			if (time.getHour() == 0) {
				dateText += 12 + ":";
			} else {
				dateText += time.getHour() + ":";
			}
			if (time.getMinute() < 10) {
				dateText += "0" + time.getMinute();
			} else {
				dateText += time.getMinute();
			}
			dateText += "AM";
		}
	}

}
