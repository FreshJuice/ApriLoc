import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.CompoundBorder;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

public class ViewUsersWindow extends JFrame {
	private static final long serialVersionUID = 672879095819277665L;
	JRadioButton viewAll;
	JRadioButton onlyOnline;

	ButtonGroup userGroup;
	JTable table;
	JScrollPane scroll;
	ArrayList<User> userArray;
	Object allUsers[][];
	String[] cols = { "First Name", "Phone Number", "ID Number" };
	JPanel userList;
	JPanel panel;
	DefaultTableModel model;

	public ViewUsersWindow() {
		// Creates the Frame
		this.setTitle("View Users");
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		// Main Panel
		panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;
		// Sub Panel for drop down
		JPanel typeUser = new JPanel();
		typeUser.setLayout(new GridBagLayout());

		viewAll = new JRadioButton("View All", true);
		onlyOnline = new JRadioButton("Only Online");
		userGroup = new ButtonGroup();
		userGroup.add(viewAll);
		userGroup.add(onlyOnline);
		onlyOnline.addActionListener(new OnlineUsers());
		viewAll.addActionListener(new AllUsers());

		typeUser.add(viewAll, c);
		c.gridx++;
		typeUser.add(onlyOnline, c);
		c.gridx++;

		c.gridx = 0;
		c.gridy = 0;
		panel.add(typeUser);

		// Sub Panel for reason
		userList = new JPanel();
		CompoundBorder tb = BorderFactory.createCompoundBorder();
		userList.setBorder(tb);

		allUsers = new Object[ServerConnection.getAllUsers().size()][3]; // num
																			// rows
																			// uknown
																			// col
																			// is
																			// fixed
		userArray = ServerConnection.getAllUsers();
		for (int i = 0; i < userArray.size(); i++) {
			User proccessUser = (User) userArray.get(i);
			allUsers[i][0] = proccessUser.getName();
			allUsers[i][1] = proccessUser.getPhoneNumber();
			allUsers[i][2] = proccessUser.getUserID();

		}
		table = new JTable();
		model = new DefaultTableModel(allUsers, cols);
		table.setModel(model);

		table.setDefaultEditor(Object.class, null);
		table.setBackground(Color.yellow);
		table.setForeground(Color.blue);
		userList.add(new JScrollPane(table));
		c.gridy++;
		panel.add(userList, c);

		this.add(panel);
		this.pack();
	}

	private class OnlineUsers implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			if (onlyOnline.isSelected()) {
				userArray = ServerConnection.getAllUsers();
				Object[][] allUsers = new Object[ServerConnection.getAllUsers().size()][3];
				int j = 0; // num of online users

				for (int i = 0; i < userArray.size(); i++) {

					User proccessUser = (User) userArray.get(i);
					if (proccessUser.isLoggedIn()) {
						allUsers[j][0] = proccessUser.getName();
						allUsers[j][1] = proccessUser.getPhoneNumber();
						allUsers[j][2] = proccessUser.getUserID();
						j++;
					}

				}
				model = new DefaultTableModel(allUsers, cols);
				table.setModel(model);

				// Removes the empty rows
				for (int i = userArray.size(); j < i; i--) {
					model.removeRow(i - 1);
				}

			}

		}
	}

	private class AllUsers implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {

			if (viewAll.isSelected()) {
				userArray = ServerConnection.getAllUsers();
				Object[][] online = new Object[ServerConnection.getAllUsers().size()][3];

				for (int i = 0; i < userArray.size(); i++) {
					User proccessUser = (User) userArray.get(i);
					online[i][0] = proccessUser.getName();
					online[i][1] = proccessUser.getPhoneNumber();
					online[i][2] = proccessUser.getUserID();
					proccessUser.isLoggedIn();
				}
				model = new DefaultTableModel(online, cols);
				table.setModel(model);
			}
		}
	}
}