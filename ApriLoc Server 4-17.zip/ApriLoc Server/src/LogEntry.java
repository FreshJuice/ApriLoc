import java.io.Serializable;

public class LogEntry implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3506163563391507760L;
	private long timeStamp;
	private int attemptedLoginID;
	private int loginAttemptNum;
	
	public LogEntry(long timeStamp, int attemptedLoginID, int loginAttemptNum){
		this.timeStamp = timeStamp;
		this.attemptedLoginID = attemptedLoginID;
		this.loginAttemptNum = loginAttemptNum;
	}
	
	public long getTimeStamp(){
		return this.timeStamp;
	}
	
	public int getLoginID(){
		return this.attemptedLoginID;
	}
	
	public int getLoginAttemptNum(){
		return this.loginAttemptNum;
	}
}
