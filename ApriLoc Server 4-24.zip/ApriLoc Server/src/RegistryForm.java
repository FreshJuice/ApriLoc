import java.io.Serializable;

public class RegistryForm implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -361248008231584620L;
	private int userID;
	private String requestedPrivlage;
	private String bodyText;
	private boolean isPending;
	private boolean isApproved;

	public RegistryForm(int userID, String requestedPrivlage, String bodyText) {
		this.userID = userID;
		this.requestedPrivlage = requestedPrivlage;
		this.bodyText = bodyText;
		isPending = true;
		isApproved = false;
	}

	public int getUserId() {
		return this.userID;
	}

	public String getRequestedPrivlage() {
		return this.requestedPrivlage;
	}

	public String getBodyText() {
		return this.bodyText;
	}

	public void setPending(boolean isPending) {
		this.isPending = isPending;
	}

	public void setApproved(boolean isApproved) {
		this.isApproved = isApproved;
	}

	public boolean isPending() {
		return isPending;
	}

	public boolean isApproved() {
		return isApproved;
	}
}