import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

public class Database implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3503005946576727667L;
	public static final String DATABASE_FOLDER = "/home/christian/Desktop/database";
	
	public static void saveUsersToFile(String folderPath) throws FileNotFoundException {
		File userFolder = new File(folderPath);
		if (userFolder.isFile())
			throw new FileNotFoundException(folderPath + "/userList.data (Not a directory)");
		userFolder.mkdirs();
		try {
			FileOutputStream fos = new FileOutputStream(folderPath + "/userList.data");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			for (User obj : UserCollections.getUserList())
				oos.writeObject(obj);
			oos.flush();
			oos.close();
			fos.flush();
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static ArrayList<User> readUsersFromFile(String folderPath) throws Exception {
		File userFolder = new File(folderPath);
		if (!userFolder.isDirectory()) {
			throw new Exception(folderPath + " is not a directory");
		}
		ArrayList<User> tempUsers = new ArrayList<>();
		try {
			FileInputStream fis = new FileInputStream(folderPath + "/userList.data");
			ObjectInputStream ois = new ObjectInputStream(fis);

			try {
				User temp;
				while (true){
					temp = (User) ois.readObject();
					temp.setLoggedIn(false);
					tempUsers.add(temp);
				}
			} catch (EOFException e) {

			}
			ois.close();
			fis.close();
		} catch (IOException | ClassNotFoundException e) {
			if(e instanceof FileNotFoundException)
				System.err.println(folderPath + "/userList.data (No such file)");
			else
				e.printStackTrace();
		}
		return tempUsers;
	}

	public static void saveLogsToFile(String folderPath) throws FileNotFoundException {
		File userFolder = new File(folderPath);
		if (userFolder.isFile())
			throw new FileNotFoundException(folderPath + "/logsList.data (Not a directory)");
		userFolder.mkdirs();
		try {
			FileOutputStream fos = new FileOutputStream(folderPath + "/logsList.data");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			for (LogEntry obj : UserCollections.getLogEntryList())
				oos.writeObject(obj);
			oos.flush();
			oos.close();
			fos.flush();
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static ArrayList<LogEntry> readLogsFromFile(String folderPath) throws Exception{
		File userFolder = new File(folderPath);
		if (!userFolder.isDirectory()) {
			throw new Exception(folderPath + " is not a directory");
		}
		ArrayList<LogEntry> tempLogs = new ArrayList<>();
		try {
			FileInputStream fis = new FileInputStream(folderPath + "/logsList.data");
			ObjectInputStream ois = new ObjectInputStream(fis);

			try {
				while (true)
					tempLogs.add((LogEntry) ois.readObject());
			} catch (EOFException e) {
				
			}
			ois.close();
			fis.close();
		} catch (IOException | ClassNotFoundException e) {
			if(e instanceof FileNotFoundException)
				System.err.println(folderPath + "/logsList.data (No such file)");
			else
				e.printStackTrace();
		}
		return tempLogs;
	}
	
	public static void saveRegistryFormsToFile(String folderPath) throws FileNotFoundException{
		File userFolder = new File(folderPath);
		if (userFolder.isFile())
			throw new FileNotFoundException(folderPath + "/registryFormsList.data (Not a directory)");
		userFolder.mkdirs();
		try {
			FileOutputStream fos = new FileOutputStream(folderPath + "/registryFormsList.data");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			for (RegistryForm obj : UserCollections.getRegistryFormList())
				oos.writeObject(obj);
			oos.flush();
			oos.close();
			fos.flush();
			fos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static ArrayList<RegistryForm> readRegistryFormsFromFile(String folderPath) throws Exception{
		File userFolder = new File(folderPath);
		if (!userFolder.isDirectory()) {
			throw new Exception(folderPath + " is not a directory");
		}
		ArrayList<RegistryForm> tempForms = new ArrayList<>();
		try {
			FileInputStream fis = new FileInputStream(folderPath + "/registryFormsList.data");
			ObjectInputStream ois = new ObjectInputStream(fis);

			try {
				while (true)
					tempForms.add((RegistryForm) ois.readObject());
			} catch (EOFException e) {
				
			}
			ois.close();
			fis.close();
		} catch (IOException | ClassNotFoundException e) {
			if(e instanceof FileNotFoundException)
				System.err.println(folderPath + "/registryFormsList.data (No such file)");
			else
				e.printStackTrace();
		}
		return tempForms;
	}

	public static void saveAllToFile(String folderPath) {
		try {
			saveUsersToFile(folderPath);
			saveLogsToFile(folderPath);
			saveRegistryFormsToFile(folderPath);
		} catch (Exception e) {

		}
	}
	
	public static void readAllFromFile(String folderPath) {
		try {
			UserCollections.setUserList(readUsersFromFile(folderPath));
			UserCollections.setLogEntryList(readLogsFromFile(folderPath));
			UserCollections.setRegistryFormList(readRegistryFormsFromFile(folderPath));
		} catch (Exception e) {

		}
	}
}
