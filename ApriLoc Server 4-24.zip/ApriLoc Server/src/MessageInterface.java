import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;

public class MessageInterface implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6395209342463130726L;
	private Socket client;
	private User loggedInUser;

	private ObjectOutputStream objectOutputStream;
	private ObjectInputStream objectInputStream;

	private String regFormPriv;
	private String regFormBody;

	public MessageInterface(Socket client) {
		this.client = client;
		try {
			objectOutputStream = new ObjectOutputStream(client.getOutputStream());
			objectInputStream = new ObjectInputStream(client.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}
		listenForMessages();
	}

	private void sendMessage(String message) {

		try {
			objectOutputStream.writeObject(new String(message));
			objectOutputStream.flush();
		} catch (IOException e) {
			disconnect();
			e.printStackTrace();
		}
	}

	private void sendInteger(int num) {

		try {
			objectOutputStream.writeInt(num);
			objectOutputStream.flush();
		} catch (IOException e) {
			disconnect();
			e.printStackTrace();
		}

	}

	private void handleMessages(String message) {
		String messageCode = message.substring(0, 8);
		message = message.substring(8);
		if (messageCode.equals("user----")) {
			User user = UserCollections.getUser(Integer.parseInt(message));
			sendObj(user);
		} else if (messageCode.equals("login---")) {
			String successful = message.substring(0, 1);
			String userID = message.substring(1, message.length() - 1);
			String numLoginAttemps = message.substring(message.length() - 1);

			User user = UserCollections.getUser(Integer.parseInt(userID));

			LogEntry logEntry = new LogEntry(System.currentTimeMillis(), Integer.parseInt(userID),
					Integer.parseInt(numLoginAttemps));

			UserCollections.addLogEntry(logEntry);

			if (successful.equals("t")) {
				user.setLoggedIn(true);
				loggedInUser = user;
			}
		} else if (messageCode.equals("regForm1")) {
			regFormPriv = message;
		} else if (messageCode.equals("regForm2")) {
			regFormBody = message;
		} else if (messageCode.equals("regForm3")) {
			UserCollections.addRegistryForm(new RegistryForm(Integer.parseInt(message), regFormPriv, regFormBody));
		} else if (messageCode.equals("allUsers")) {
			sendInteger(UserCollections.getUserList().size());
			for (int i = 0; i < UserCollections.getUserList().size(); i++) {
				sendObj(UserCollections.getUserList().get(i));
			}
		} else if (messageCode.equals("newAdmin")) {
			Administrator administrator = (Administrator) recieveObj();
			UserCollections.addUser(administrator);
		} else if (messageCode.equals("newUser-")) {
			UserAccount userAccount = (UserAccount) recieveObj();
			UserCollections.addUser(userAccount);
		} else if (messageCode.equals("rmuser--")) {
			int userID = Integer.parseInt(message);
			UserCollections.removeUser(userID);
		} else if (messageCode.equals("getRegFm")) {
			sendInteger(UserCollections.getRegistryFormList().size());
			for (int i = 0; i < UserCollections.getRegistryFormList().size(); i++) {
				sendObj(UserCollections.getRegistryFormList().get(i));
			}
		} else if (messageCode.equals("update--")) {
			User user = (User) recieveObj();
			for (int i = 0; i < UserCollections.getUserList().size(); i++) {
				if (UserCollections.getUserList().get(i).getUserID() == user.getUserID()) {
					UserCollections.getUserList().remove(i);
					UserCollections.addUser(user);
				}
			}
		}
	}

	private Object recieveObj() {
		try {
			return objectInputStream.readObject();
		} catch (ClassNotFoundException | IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	private void sendObj(Object obj) {
		try {
			objectOutputStream.reset();
			objectOutputStream.writeObject(obj);
			objectOutputStream.flush();
		} catch (IOException e) {
			disconnect();
			e.printStackTrace();
		}
	}

	private void listenForMessages() {
		new Thread() {
			@Override
			public void run() {
				ObjectInputStream asd = objectInputStream;
				while (true) {
					try {
						System.out.println("Waiting for message");
						String message = asd.readUTF();
						System.out.println("Receieved Message: " + message + "\n");
						if (message == null) {
							disconnect();
							break;
						} else {
							handleMessages(message);
						}
					} catch (IOException e) {
						disconnect();
						break;
					}
				}

				super.run();
			}
		}.start();
	}

	private void disconnect() {
		try {
			UserCollections.getUser(loggedInUser.getUserID()).setLoggedIn(false);
		} catch (Exception e) {

		}
		Server.disconnect(client);
	}
}
